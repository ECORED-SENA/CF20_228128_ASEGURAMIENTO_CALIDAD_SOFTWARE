function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5nN6o4bEOYV":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

